/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */

// Core
import Button from '@client/components/Button';
import Input from '@client/components/Input';

import type { Option, Options, PollNode } from './PollNode';

import './PollNode.css';

import { useCollaborationContext } from '@lexical/react/LexicalCollaborationContext';
import { useLexicalComposerContext } from '@lexical/react/LexicalComposerContext';
import { useLexicalNodeSelection } from '@lexical/react/useLexicalNodeSelection';
import { mergeRegister } from '@lexical/utils';
import {
    $getNodeByKey,
    $getSelection,
    $isNodeSelection,
    BaseSelection,
    CLICK_COMMAND,
    COMMAND_PRIORITY_LOW,
    KEY_BACKSPACE_COMMAND,
    KEY_DELETE_COMMAND,
    NodeKey,
} from 'lexical';
import * as React from 'react';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';

import joinClasses from '../utils/joinClasses';
import { $isPollNode, createPollOption } from './PollNode';

function getTotalVotes(options: Options): number {
    return options.reduce((totalVotes, next) => {
        return totalVotes + next.votes.length;
    }, 0);
}

function PollOptionComponent({
    option,
    index,
    options,
    totalVotes,
    withPollNode,
}: {
    index: number;
    option: Option;
    options: Options;
    totalVotes: number;
    withPollNode: (
        cb: (pollNode: PollNode) => void,
        onSelect?: () => void,
    ) => void;
}): React.JSX.Element {

    const { clientID } = useCollaborationContext();
    const checkboxRef = useRef(null);
    const votesArray = option.votes;
    const checkedIndex = votesArray.indexOf(clientID);
    const checked = checkedIndex !== -1;
    const votes = votesArray.length;
    const text = option.text;

    return (
        <div className="row sp-05" style={{ position: 'relative' }}>
            <div
                className={joinClasses(
                    'PollNode__optionCheckboxWrapper',
                    checked && 'PollNode__optionCheckboxChecked',
                )}>
                <input
                    ref={checkboxRef}
                    className="PollNode__optionCheckbox"
                    type="checkbox"
                    onChange={(e) => {
                        withPollNode((node) => {
                            node.toggleVote(option, clientID);
                        });
                    }}
                    checked={checked}
                />
            </div>
            <div
                className="PollNode__optionInputVotes"
                style={{ width: `${votes === 0 ? 0 : (votes / totalVotes) * 100}%` }}
            />
            <span className="PollNode__optionInputVotesCount">
                {votes > 0 && (votes === 1 ? '1 vote' : `${votes} votes`)}
            </span>
            <Input
                wrapper={false}
                value={text}
                onChange={(value) => {
                    withPollNode(
                        (node) => {
                            node.setOptionText(option, value);
                        },
                        () => {
                            
                        },
                    );
                }}
                title={`Option ${index + 1}`}
                className="col-1"
            />
            <Button
                disabled={options.length < 3}
                icon="times"
                onClick={() => {
                    withPollNode((node) => {
                        node.deleteOption(option);
                    });
                }}
            />
        </div>
    );
}

export default function PollComponent({
    question,
    options,
    nodeKey,
}: {
    nodeKey: NodeKey;
    options: Options;
    question: string;
}): React.JSX.Element {

    const [editor] = useLexicalComposerContext();
    const totalVotes = useMemo(() => getTotalVotes(options), [options]);
    const [isSelected, setSelected, clearSelection] =
        useLexicalNodeSelection(nodeKey);
    const [selection, setSelection] = useState<BaseSelection | null>(null);
    const ref = useRef(null);

    const $onDelete = useCallback(
        (payload: KeyboardEvent) => {
            const deleteSelection = $getSelection();
            if (isSelected && $isNodeSelection(deleteSelection)) {
                const event: KeyboardEvent = payload;
                event.preventDefault();
                editor.update(() => {
                    deleteSelection.getNodes().forEach((node) => {
                        if ($isPollNode(node)) {
                            node.remove();
                        }
                    });
                });
            }
            return false;
        },
        [editor, isSelected],
    );

    useEffect(() => {
        return mergeRegister(
            editor.registerUpdateListener(({ editorState }) => {
                setSelection(editorState.read(() => $getSelection()));
            }),
            editor.registerCommand<MouseEvent>(
                CLICK_COMMAND,
                (payload) => {
                    const event = payload;

                    if (event.target === ref.current) {
                        if (!event.shiftKey) {
                            clearSelection();
                        }
                        setSelected(!isSelected);
                        return true;
                    }

                    return false;
                },
                COMMAND_PRIORITY_LOW,
            ),
            editor.registerCommand(
                KEY_DELETE_COMMAND,
                $onDelete,
                COMMAND_PRIORITY_LOW,
            ),
            editor.registerCommand(
                KEY_BACKSPACE_COMMAND,
                $onDelete,
                COMMAND_PRIORITY_LOW,
            ),
        );
    }, [clearSelection, editor, isSelected, nodeKey, $onDelete, setSelected]);

    const withPollNode = (
        cb: (node: PollNode) => void,
        onUpdate?: () => void,
    ): void => {
        editor.update(
            () => {
                const node = $getNodeByKey(nodeKey);
                if ($isPollNode(node)) {
                    cb(node);
                }
            },
            { onUpdate },
        );
    };

    const addOption = () => {
        withPollNode((node) => {
            node.addOption(createPollOption());
        });
    };

    const isFocused = $isNodeSelection(selection) && isSelected;

    return (
        <div
            className={`PollNode__container ${isFocused ? 'focused' : ''}`}
            ref={ref}>
            <div className="PollNode__inner">
                <h2 className="PollNode__heading">{question}</h2>
                {options.map((option, index) => {
                    const key = option.uid;
                    return (
                        <PollOptionComponent
                            key={key}
                            withPollNode={withPollNode}
                            option={option}
                            index={index}
                            options={options}
                            totalVotes={totalVotes}
                        />
                    );
                })}
                <div className="PollNode__footer">
                    <Button icon="plus" onClick={addOption}>
                        Add Option
                    </Button>
                </div>
            </div>
        </div>
    );
}
