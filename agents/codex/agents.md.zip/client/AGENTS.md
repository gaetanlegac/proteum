# Frontend designing

UI components are defined in `/client/pages` (pages) and `/client/components` (reusable components).

## Stack

- Typescript strict
- Preact with SSR
- Base UI (components logic)
- framer-motion wrapper in `@/client/components/Motion` (animations)
- Tailwind CSS 4 (styling)

Don't use React.useCallback unless strictly necessary.

## Communicate with the server (fetch & send data)

1. First, import the server service instance from @app:
`import { ServiceName } from '@app';`

2.a: Fetch data via SSR (synchronous, preferred). Only on page components.

```typescript
const { talents } = api.fetch({
    talents: ServiceName.MethodName({ param1: 'myValue1' }),
});
```

2.b: Fetch / send asynchronously (possible on all type of component)

```typescript
const handleClick = () => ServiceName.MethodName({ ... })
    .then( result => ... )
    .catch( e => .... );
...
<button onClick={handleClick}>
```

The throwed errors wil automatically be displayed to the user, so don't handle them in the catch method.

**WARN**: Never use await on server service methods. Always use .then and .catch chaining instead.

```typescript 
Headhunters.login({
    email: trimmedEmail,
    password,
}).then(response => {

    console.log('handleSubmit response', response);

}).catch(err => {

    console.error('handleSubmit error', err);
    throw err;
    
}).finally(() => {

    setLoading(false);

})
```

### Errors handling

Errors catched from server service methods should never be silented.
Instead, throw them again, so the api client can handle the error correctly.

## Design

- Beautiful, modern, minimalist and intuitive design
- Responsive layout
- Enhance the UX by integrating animations (use the )

## Rules

- Always import React in react files (.tsx)
- Don't use any component from `@client/components`
- To create a link / button, always use the Link component:
```typescript
import { Link } from '@client/components';
...
<Link to="/dashboard/google" className="/dashboard/google">Button text</Link>
```

### Keep the code organized
- Split big components (more than 1000 lines) into smaller components
- Always use one component per file
- Everytime possible, load data & define the action handlers in the directly concerned component instead dof passing them from parent through attributes.

## Split the page by sections via comments

/*----------------------------------
- SECTION NAME
----------------------------------*/

File sections:
- DEPENDENCIES: All the imports, grouped by category: Npm, Core (`@xxx/xxx`), App (`@/xxx/xxx`), 
- TYPES: type definitions and imports
- COMPONENT / PAGE: The definition of the page / component (only one per file)

Component / page sections:
- INIT: States, api.fetch, ...
- ACTIONS: Handlers, useEffect, ...
- RENDER: Render the component

Example:

```typescript
/*----------------------------------
- DEPENDENCIES
----------------------------------*/

// Npm
import React from 'react';
import {
    ArrowRight
} from 'lucide-preact';

// Core
import { Link } from '@client/components';

// App
import { ServiceName } from '@app';
import Page from '@/client/pages/_layout/_page';

/*----------------------------------
- TYPES
----------------------------------*/

/*----------------------------------
- PAGE
----------------------------------*/
Router.page('/recruiter/talents', ({ page, api, app }) => {

    /*----------------------------------
    - INIT
    ----------------------------------*/

    const [param1, setParam1] = React.useState<string>('myValue1');

    const { talents } = api.fetch({

        talents: ServiceName.MethodName({ param1: 'myValue1' }),

    });

    /*----------------------------------
    - ACTIONS
    ----------------------------------*/

    const method2 = (param2: string) => MyService.MyMethod2({ param1, param2 }).then( result => {

        ...

    })

    // Update filters
    React.useEffect(() => {

        // Re-retch talents with different params
        api.reload(['talents'], { param1 });

    }, [param1]);

    /*----------------------------------
    - RENDER
    ----------------------------------*/
    return (
        <Page title="Page title">

            {/* Page content with Tailwind CSS here */}

            <Link
                to="/"
                className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white px-10 py-4 rounded-xl font-semibold transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-2 hover:scale-105 transform"
            >
                Link 1
                <ArrowRight size={20} />
            </Link>

            <button
                onClick={method2}
                className="bg-white text-orange-600 hover:bg-orange-50 px-10 py-4 rounded-xl font-semibold text-lg transition-all shadow-2xl hover:shadow-2xl hover:scale-105 transform flex items-center gap-2"
            >
                Button 1
            </button>
            
        </Page>
    )
});
```