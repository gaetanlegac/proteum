# Page files

Page files are located in `/client/pages/**/*.tsx`

## Typings

Never cast the `@app` service methods, their attributes and their return type. 
Treat then as the definitive typings, and adapt the frontend components to it, as server typings are priorized over client typings.
Always call them inline.