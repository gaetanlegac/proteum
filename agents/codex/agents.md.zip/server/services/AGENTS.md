# Server Services

Stack:
- Typescript with strict mode
- NodeJS
- Prisma 7 ORM

When you create a service, follow these steps:

## 1. Create the service file in /server/services/<service name>/index.ts

Template:
```typescript
/*----------------------------------
- DEPENDANCE
----------------------------------*/

// Npm packages
import path from 'path';

// Core libs
import Service, { schema, Route } from '@server/app/service';
import { auth, context } from '@request';

// App services
import { CSM, Discord } from '@app';

// Specific to this service

/*----------------------------------
- TYPES
----------------------------------*/

export type Config = <ServiceConfig>

/*----------------------------------
- LIB
----------------------------------*/
export default class ServiceName extends Service<Config, {}, CrossPath, CrossPath> {

    public async MethodName({ param1 }: { param1: string }) {

        <method code>

    }
}
```

<ServiceConfig> is an object containing apiKeys and other variables we can adjust in the future
Preserve the same structure and type of code formatting.

# 2. Create the service metas file in /server/services/<service name>/service.json

```json
{
    "id": "CrossPath/ServiceName",
    "name": "CrossPathServiceName",
    "parent": "app",
    "dependences": []
}
```

## 3. Register the service in the /server/config/crosspath.ts config file

```typescript
app.setup('ServiceName', 'CrossPath/ServiceName', <ServiceConfig>);
```

## 4. Keep classes clean, separate concern

## Subservices

If the class grows too large (+500 lines) and mixes concerns, split the class methods into a subservice (a separate service classes that are children if this current class), grouping them by responsibility. The subservice is instanciated in the parent service:

`public editor = new MissionEditor(/* parent */this, /* config */null, /* app */this.app);`

Allow hierarchical organization: related classes can be instantiated as properties (“subclasses”) inside the parent to encapsulate sub-areas of operation.
Use consistent naming and folder structure to reflect each area of operation.

## 5. Call service method from frontend (`client/pages/`)

Expose server service methods to client pages by adding the `@Route` decorator on these methods:

```typescript
@Route( <route path>, schema.object({
    param1: schema.string()
}))
public async MethodName({ param1 }: { param1: string }) {
    
    <method code>

}
```

* schema.object defines a zod schema for validating the method argument
Validation helpers `schema` come from `@server/app/service`
* The first argument is the <route path>: equal to the property/method access chain, replacing dots with slashes.
- Follow property names exactly as in the class (e.g. `Crm.leads.listSaasLeads` → `Crm/leads/listSaasLeads`).
- Include methods of subclasses/services instantiated as public properties.
- Keep original method names and order.

Example:

```typescript
export default class CrmService extends Service<Config, {}, CrossPath, CrossPath> {
    public leads = new LeadsService(this, null, this.app);
}
```

```typescript
export default class CrmLeadsService extends Service<Config, Hooks, CrossPath, CrmService> {

    public async listSaasLeads(): Promise<SaasLeadDto[]> {

}
}
``` 

Route path: Crm/leads/listSaasLeads

## 6. Use request-aware features (request services)

Those are available from the `@request` import:
`import { request, auth, context, response } from '@request';`

ONLY consume the `@request` services in:
- `server/service`: Service class methods **prefixed with a @Route decorator only**
NEVER consume these services elsewhere than the mentionned places above. 

* To require the user to be authenticated and to get the current logged `user`, use `const user = auth.check('USER');`

## 7. Fetch and return data from database

Data fetching should be structured as the following:

1. Retrieve method parameters after they've been filtred by the zod schema
2. Construct prisma query
3. Run prisma query
4. Map the results to expose the correct DTO
5. Return the DTO

```typescript
export default class CrmLeadsService extends Service<Config, Hooks, CrossPath, CrmService> {

    /*----------------------------------
    - LEADS
    ----------------------------------*/
    @Route('Crm/leads/listLeads', schema.object({
        type: schema.enum(['saas', 'headhunter']),
        includeLead: schema.boolean().optional(),
        page: schema.number().int().min(1).optional(),
        pageSize: schema.number().int().min(1).max(MAX_PAGE_SIZE).optional(),
        sortBy: schema.string().optional(),
        sortDir: schema.enum(['asc', 'desc']).optional(),
        search: schema.string().optional()
    }))
    public async listLeads({
        type,
        includeLead = true,
        page = 1,
        pageSize = DEFAULT_PAGE_SIZE,
        sortBy,
        sortDir = 'asc',
        search
    }: {
        type: 'saas' | 'headhunter';
        includeLead?: boolean;
        page?: number;
        pageSize?: number;
        sortBy?: string;
        sortDir?: 'asc' | 'desc';
        search?: string;
    }) {
        
        const user = await auth.check('USER');

        // Pagination
        const normalizedPage = Math.max(1, page);
        const normalizedPageSize = Math.min(Math.max(pageSize, 1), MAX_PAGE_SIZE);
        const skip = (normalizedPage - 1) * normalizedPageSize;

        // Fetch leads
        const visibilityWhere = buildLeadVisibilityWhere(user);
        const where: Models.Prisma.CrmLeadWhereInput = {
            AND: [
                // SaaS Leads only
                { type: CrmLeadType.Saas }, 
                // Visibility
                visibilityWhere,
            ]
        };

        const total = await CrmLead.count({ where });

        const items = await CrmLead.findMany({
            include: {
                ...
            },
            where,
            skip,
            take: normalizedPageSize
        }).then(leads => leads.map(lead => ({

            // Universal
            name: lead.contact.firstName + ' ' + lead.contact.lastName,
            ...
        })));

        return {
            items,
            page: normalizedPage,
            pageSize: normalizedPageSize,
            total,
            hasNextPage: skip + items.length < total
        };
    }
}
```

### Prisma usage

- Never edit prisma files, except the schema.
- To import a prisma model for consuming / writing data (only available on server side)
```typescript
import { MyModel } from '@models';
...
const results = await MyModel.findMany({ ... });
```

ONLY consume the `@models` models `server/service`, Service class methods only.
NEVER consume these models elsewhere than the mentionned places above. 

- To get the type Typescript of a Prisma model
```typescript
import type * as Models from '@models/types';
...
let myModel: Models.MyModel;
```

- Never use `mode: insentive` as the database is already configurated with a insensitive charset
- In all queries  & joins, always specify what fields to select so we don't load useless fields.

## Rules

### Don't create DTO types when we can infer the exact returned data

If you need to get the type of results / DTO returned by these methods, infer them by this way:

`export type TLeadResults = Awaited<ReturnType<CrmLeadsService["listLeads"]>>;`

Don't create types while we can simply infer from the return type

### Errors handling

Unhandled errors are always passed to the `bug` app hook, which report it to the devs team.
That's why you should never silent the errors you catch.
Always throw Anomaly with 1. enough details to solve the issue quickly and 2. the original error object ; instead of logging.
