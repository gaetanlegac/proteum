# Server routes

## Generate absolute urls

The absolute urls are generated via the Router.url() function:

`const absoluteUrl = Router.url('/relative/path')`