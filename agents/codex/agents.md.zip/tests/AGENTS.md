# Codex guidance for writing E2E tests

- Understand what is the typical user flow, and all the possible features usage
- Favorize as many tests as possible to cover 
- Always locate the elemnts via their data-testid attribute.
Add the data-testid attribute to the elements you test if needed
- Keep the test files clean, organized and structured.