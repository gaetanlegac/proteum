# Architecture

This is a full stack monolith project using Typescript, NodeJS, Preact, and a custom full-stack framework called 5HTP.

`/client`: frontend
    `/assets`: CSS, Images and other assets for frontend
    `/components`: All the reusable components
    `/pages`: Client `pages` declarations
    `/hooks`
`/common`: common functions, constants and typings between frontend and backend
`/server`: backend
    `/config`: Configuration of server `services`
    `/services`: Where server service are declared
    `/routes`: Server routes declaration
    `/lib`: Never put helper functions as class method. Put all helper functions here. 
        Utility functions = independant from any `services` instances
/tests

# Coding style

- **The code should be at the highest level of industry, as the product will be used by GAFAMs and will be maintained y a team of 10 developpers.**
- Write clean, consistant, readable and highly commented code with a tab size of 4.
- Keep functions and method short. Everytime possible, create **reusable** functions and components instead of repeating

# Files organization

- Always keep one class / react component per file
- Keep in mind the project will expand across time, so prefer having a deep tree structure of files that group files by similar use / business need / purpose, rather than having long file names.

## Centralize feature catalogs (Single Source of Truth)

When implementing a feature that relies on a **curated list of “items”**, **DO NOT spread const definitions across the codebase** (client UI lists, server builders, category enums in other places, etc.).

**Rule (MUST):** For each such feature, maintain **one canonical “catalog/registry” file** that contains the complete definition of every item and everything needed to use it. All other code (client + server) must **import/consume** this catalog instead of redefining partial lists.

When adding a new item, the change should be **Only** in the catalog file. Not “update 3 lists in 3 places”.

## Special imports

- `@models`: Prisma models instances. 
- `@models/types`: Typings for prisma models. Can be accesses anywhere.
- `@app`: Application service instances. 

# Concepts

## Services

Classes that are instanciated on backend when the app starts.

Their instance are accessible only via the @app spread import:
`import { Router, Email, MyServiceName } from '@app';`

ONLY consume the `@app` service instances in:
- `server/service`: Service class methods only
- `client/pages` and `client/components`: Inside React components only
NEVER consume these service instance elsewhere than the mentionned places above. 

The @app module is exposing the properties of the instance of the app class, located here:
`/server/.generated/app.ts`

# Agent behavior

**Make sure the code you generate integrates perfectly with the current codebase by avoiding repetition and centralizing each purpose.**

## Typings

- Fix typing issues only on the code you wrote. 
- Never force cast with `unknown` or `any`. If you find no other solutions, tell me in the output.

## Workflow

- Everytime I input error messages without any instructions, don't implement fixes.
Instead, ivestigate the potential causes of the errors, and for each: 
    1. Evaluate / quantify the probabiliies 
    2. Give why and 
    3. Suggest how to fix it
- When you have finished your work, summarize in one top-level short sentence the changes you made since the beginning of the conversation. Output as "Commit message".

## Never edit the following files

- Prisma files (except schema.prisma)
- tsconfigs
- env
- Any file / folder that is a symbolic link

If you need to edit them, just suggest in the chat.

## Don't run any of these commands

```
git restore
git reset
prisma *
And any git command in the write mode.
```

# Copy and UX
Before making UX/copy decisions, read `docs/PERSONAS.md`, `docs/PRODUCT.md`, `docs/MARKETING.md`.